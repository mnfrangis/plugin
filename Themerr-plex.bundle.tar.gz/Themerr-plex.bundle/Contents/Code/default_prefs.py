default_prefs = dict(
    bool_prefer_mp4a_codec='True',
    int_plexapi_plexapi_timeout='180',
    int_plexapi_upload_retries_max='3',
    int_plexapi_upload_threads='3',
    str_youtube_user='',
    str_youtube_passwd=''
)
